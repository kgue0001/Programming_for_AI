function PostDataToServer (){
          var fdata = new FormData();
          var request = new XMLHttpRequest ();
          var jresp;
          var textinput = document.getElementById("textinput");
          fdata.append ("textinput", textinput.value);
          request.open("Post","http://192.168.0.12/python2", false);
          request send(fdata);
          jresp = JSON,parse (request.responseText);
          console.log(jresp);
          }
