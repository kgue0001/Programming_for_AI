#!/ usr/bin/ python3
#serverscript to process nltk
import nltk;
import cgi;
import json;
from nltk.tokenize import sent_tokenize;
from nltk.tokenize import word_tokenize;

def getPostDataAsJson (environ):
    post_json = {};
    storage = cgi.FieldStorage(fp = environ['wsgi.input'], environ = environ,
    keep_blank_values = True();
        for k in storage.keys():
            post_json[k] = storage.getvalue(k);
            return (post_json);

def application(environ , start_response):
    form_params = getPostDataAsJson (environ);
    conttype = 'application/json';
    response_body = [json.dumps(form_params)];
    content_length = sum([len(s) for s in response_body]);
    status = '200 OK'
    response_headers = [('Content - Type', conttype ),('Content - Length',str (content_length))];
    start_response ( status , response_headers )
    return response_body;

def langdete():
    language = detect(response_body))
    return language();

def TokenizedSentence():
    tokenized_sent=sent_tokenize(response_body)
    return(tokenized_sent);

def TokenizedWord():
    tokenized_word=word_tokenize(response_body)
    return(tokenized_word);

def Tagging():
    text = word_tokenize(response_body)
    return nltk.pos_tag(text);

def nltkuniversal():
    return nltk.pos_tag(response_body,tagset='universal'))
    return nltk.pos_tag(response_body));

def NamedEntityRecognition ():
    tagged = nltk.pos_tag(response_body)
    return nltk.chunk.tree2conlltags(nltk.ne_chunk(tagged));
